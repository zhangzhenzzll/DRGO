classdef Budget < handle
    % One call is one candidate evaluation. Initialization and repeats count.
    properties (SetAccess = private)
        Limit
        Count = 0
        Best = Inf
        BestPosition = []
        Grid
        Curve
        ObjectiveSeconds = 0
        LastImprovementFE = 0
    end
    properties (Access = private)
        Fun
        Lower
        Upper
        Next = 1
        ProfileObjective = false
    end
    methods
        function obj = Budget(fun,n,limit,lb,ub,profile)
            validateattributes(limit,{'numeric'},{'scalar','integer','>=',n});
            obj.Fun=fun; obj.Limit=limit; obj.Lower=lb; obj.Upper=ub;
            obj.Grid=unique(round(linspace(n,limit,101)));
            obj.Curve=nan(size(obj.Grid));
            if nargin>=6, obj.ProfileObjective=profile; end
        end
        function value = evaluate(obj,x)
            if obj.Count>=obj.Limit
                error('DRGO:BudgetReached','Evaluation budget exhausted.');
            end
            x=reshape(x,1,[]);
            if numel(x)~=numel(obj.Lower) || ~isreal(x) || any(~isfinite(x)) || any(x<obj.Lower) || any(x>obj.Upper)
                error('DRGO:InvalidCandidate','Nonfinite, complex or out-of-bounds candidate.');
            end
            if obj.ProfileObjective, start=tic; end
            value=obj.Fun(x);
            if obj.ProfileObjective, obj.ObjectiveSeconds=obj.ObjectiveSeconds+toc(start); end
            obj.Count=obj.Count+1;
            if ~isnumeric(value) || ~isscalar(value) || ~isreal(value) || ~isfinite(value)
                error('DRGO:InvalidObjective','Objective must return one finite real scalar.');
            end
            if value<obj.Best, obj.Best=value; obj.BestPosition=x; obj.LastImprovementFE=obj.Count; end
            while obj.Next<=numel(obj.Grid) && obj.Count>=obj.Grid(obj.Next)
                obj.Curve(obj.Next)=obj.Best; obj.Next=obj.Next+1;
            end
        end
        function s = result(obj)
            s=struct('best',obj.Best,'bestPosition',obj.BestPosition, ...
                'fes',obj.Count,'budget',obj.Limit,'feGrid',obj.Grid, ...
                'curve',obj.Curve,'objectiveSeconds',obj.ObjectiveSeconds, ...
                'objectiveProfiling',obj.ProfileObjective,'lastImprovementFE',obj.LastImprovementFE, ...
                'stagnationFEs',obj.Count-obj.LastImprovementFE);
        end
    end
end
