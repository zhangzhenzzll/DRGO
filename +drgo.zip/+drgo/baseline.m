function [diagnostics,seconds] = baseline(b,name,n,d,lb,ub,seed)
% Run an audited baseline under an exact objective-evaluation budget.
% The constant-objective probe determines the release's per-iteration call
% schedule without spending any real objective evaluations. The real run is
% then stopped by Budget exactly at the declared FE limit.
assert(all(lb==lb(1)) && all(ub==ub(1)), ...
    'Audited baseline adapters currently require equal bounds in all dimensions.');
fun=str2func(['baseline_' name]); calls=0;
% Probe at horizons 2 and 3: some releases divide by MaxIt-1 at MaxIt=1.
rng(seed,'twister'); [~,~,~]=fun(n,2,lb(1),ub(1),d,@counter,1); c2=calls;
calls=0; rng(seed,'twister'); [~,~,~]=fun(n,3,lb(1),ub(1),d,@counter,1); c3=calls;
perGeneration=c3-c2; initial=c2-2*perGeneration;
if perGeneration<=0 || initial<0
    error('DRGO:BaselineSchedule','Cannot infer evaluation schedule for %s.',name);
end
horizon=max(1,ceil((b.Limit-initial)/perGeneration));
rng(seed,'twister'); start=tic;
try
    [~,~,~]=fun(n,horizon,lb(1),ub(1),d,@objective,1);
catch ME
    if ~strcmp(ME.identifier,'DRGO:BudgetReached'), rethrow(ME); end
end
seconds=toc(start);
if b.Count~=b.Limit
    error('DRGO:IncompleteBaseline', ...
        '%s returned at %d of %d evaluations; no padding is permitted.', ...
        name,b.Count,b.Limit);
end
diagnostics=zeros(0,6);
    function y=counter(~,~)
        calls=calls+1; y=1;
    end
    function y=objective(x,~)
        y=b.evaluate(x);
    end
end
