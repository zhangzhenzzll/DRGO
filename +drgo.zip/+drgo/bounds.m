function [lb,ub] = bounds(lb,ub,d)
validateattributes(d,{'numeric'},{'scalar','integer','positive'});
lb=reshape(lb,1,[]); ub=reshape(ub,1,[]);
if isscalar(lb), lb=repmat(lb,1,d); end
if isscalar(ub), ub=repmat(ub,1,d); end
assert(numel(lb)==d && numel(ub)==d && all(isfinite(lb)) && all(isfinite(ub)) && all(ub>lb),'Invalid bounds.');
end
