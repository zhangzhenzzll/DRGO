function diagnostics = clpso(b,n,d,lb,ub)
% Paper-parameter CLPSO, with inertia indexed by FE rather than generation.
% Pc 0.05..0.5, exponential factor 10, gap 7, c=1.49445, vmax=.2 range.
% Infeasible positions continue flying but are NOT evaluated or clipped.
x=lb+rand(n,d).*(ub-lb); pf=zeros(n,1);
for i=1:n, pf(i)=b.evaluate(x(i,:)); end
p=x; vmax=0.2*(ub-lb); v=(2*rand(n,d)-1).*vmax;
pc=0.05+0.45*expm1(10*(0:n-1)'/(n-1))/expm1(10);
exemplar=repmat((1:n)',1,d); stale=7*ones(n,1); proposals=0;
while b.Count<b.Limit
    w=0.9-0.5*(b.Count-n)/max(1,b.Limit-n);
    for i=1:n
        if b.Count>=b.Limit, break; end
        if stale(i)>=7
            exemplar(i,:)=i; others=[1:i-1,i+1:n];
            for j=1:d
                if rand<pc(i)
                    ix=others(randperm(n-1,2));
                    if pf(ix(1))<pf(ix(2)), exemplar(i,j)=ix(1); else, exemplar(i,j)=ix(2); end
                end
            end
            if all(exemplar(i,:)==i), exemplar(i,randi(d))=others(randi(n-1)); end
            stale(i)=0;
        end
        target=p(sub2ind([n,d],exemplar(i,:),1:d));
        v(i,:)=max(-vmax,min(vmax,w*v(i,:)+1.49445*rand(1,d).*(target-x(i,:))));
        x(i,:)=x(i,:)+v(i,:); proposals=proposals+1;
        if proposals>100*b.Limit, error('DRGO:CLPSOStalled','Proposal cap reached; run is incomplete.'); end
        if any(x(i,:)<lb) || any(x(i,:)>ub), continue; end
        val=b.evaluate(x(i,:));
        if val<pf(i), p(i,:)=x(i,:); pf(i)=val; stale(i)=0;
        else, stale(i)=stale(i)+1; end
    end
end
diagnostics=zeros(0,6);
end
