function diagnostics = de(b,n,d,lb,ub)
% Canonical DE/rand/1/bin with F=0.5 and CR=0.9. FE controlled.
x=lb+rand(n,d).*(ub-lb); fit=zeros(n,1);
for i=1:n, fit(i)=b.evaluate(x(i,:)); end
while b.Count<b.Limit
    old=x; of=fit;
    for i=1:n
        if b.Count>=b.Limit, break; end
        allowed=[1:i-1,i+1:n];
        f=0.5; cr=0.9; r=allowed(randperm(n-1,3));
        v=drgo.repair(old(r(1),:)+f*(old(r(2),:)-old(r(3),:)),lb,ub,'reflect');
        mask=rand(1,d)<cr; mask(randi(d))=true;
        trial=old(i,:); trial(mask)=v(mask); val=b.evaluate(trial);
        if val<=of(i)
            x(i,:)=trial; fit(i)=val;
        end
    end
end
diagnostics=zeros(0,6);
end
