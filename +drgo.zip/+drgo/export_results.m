function export_results(jobs,cfg)
% All raw runs retained. No failed-run omission in inferential statistics.
targetID='DRGO';
if isfield(cfg,'referenceAlgorithm'), targetID=cfg.referenceAlgorithm; end
rows=cell(numel(jobs),18); curves=cell(numel(jobs),1); diagnostics=cell(numel(jobs),1);
for i=1:numel(jobs)
    j=jobs(i); path=fullfile(cfg.outDir,'raw',[j.key '.mat']);
    if isfile(path), loaded=load(path,'record'); r=loaded.record;
    else, r=struct('status','missing','fes',0,'best',NaN,'error',NaN,'seconds',NaN,'message','Checkpoint missing','curve',[],'feGrid',[],'diagnostics',[]); end
    rows(i,:)={j.key,strjoin(j.groups,';'),j.suite,j.fid,j.d,j.n,j.budget,j.run,j.seed,j.algorithm.id, ...
        r.status,r.fes,r.best,r.error,r.seconds,j.isolated,r.message,j.algorithm.provenance};
    curves{i}=struct('fe',r.feGrid,'y',r.curve); diagnostics{i}=r.diagnostics;
end
T=cell2table(rows,'VariableNames',{'key','groups','suite','function','dimension','population','budget','run','seed', ...
    'algorithm','status','actual_fes','objective','error','seconds','isolated_timing','message','provenance'});
writetable(T,fullfile(cfg.outDir,'raw_runs.csv'));
writetable(T(~strcmp(T.status,'ok'),:),fullfile(cfg.outDir,'failures.csv'));
summary={}; pairs={}; signed={}; friedman={}; posthoc={}; rankrows={}; blocked={};
dynamics={};
wins={};
groups=cfg.groups;
for g=1:numel(groups)
    group=groups{g}; selected=find(cellfun(@(x)any(strcmp(x,group)),{jobs.groups}));
    if isempty(selected), continue; end
    U=T(selected,:); block=U(:,{'suite','dimension','population','budget'});
    [~,~,bid]=unique(block);
    for bi=1:max(bid)
        local=find(bid==bi); V=U(local,:); ids=selected(local);
        alg=unique(V.algorithm,'stable'); funs=unique(V.function); K=numel(alg); F=numel(funs);
        med=nan(F,K); means=nan(F,K); complete=true;
        for fi=1:F
            values=cell(1,K); good=false(1,K);
            for ai=1:K
                take=V.function==funs(fi) & strcmp(V.algorithm,alg{ai}); W=V(take,:);
                good(ai)=~isempty(W) && all(strcmp(W.status,'ok')) && all(W.actual_fes==W.budget);
                if ~good(ai), complete=false; end
                if good(ai)
                    values{ai}=max(0,W.error); % Only comparison view clamps tiny negative roundoff; raw untouched.
                    med(fi,ai)=median(values{ai});
                    means(fi,ai)=mean(values{ai});
                    q25=drgo.percentile(values{ai},25); q75=drgo.percentile(values{ai},75);
                    stats=[mean(values{ai}),std(values{ai}),median(values{ai}),q25,q75,q75-q25, ...
                        min(values{ai}),mean(W.seconds),std(W.seconds)];
                else, stats=nan(1,9); end
                summary(end+1,:)=[{group,V.suite(1),funs(fi),V.dimension(1),V.population(1),V.budget(1),alg{ai},height(W),sum(strcmp(W.status,'ok')),good(ai)},num2cell(stats)]; %#ok<AGROW>
            end
            reference=find(strcmp(alg,targetID),1);
            if ~isempty(reference) && all(good)
                others=setdiff(1:K,reference,'stable'); p=nan(size(others)); effect=p; methods=cell(size(others));
                for k=1:numel(others), [p(k),effect(k),methods{k}]=drgo.ranksum_test(values{reference},values{others(k)}); end
                adj=drgo.holm(p);
                for k=1:numel(others)
                    symbol='=';
                    if adj(k)<.05 && effect(k)>.5, symbol='+'; elseif adj(k)<.05 && effect(k)<.5, symbol='-'; end
                    pairs(end+1,:)={group,V.suite(1),funs(fi),V.dimension(1),V.population(1),V.budget(1),alg{others(k)},p(k),adj(k),effect(k),symbol,methods{k}}; %#ok<AGROW>
                end
            end
        end
        if complete && K>=2 && F>=2
            reference=find(strcmp(alg,targetID),1);
            if ~isempty(reference)
                others=setdiff(1:K,reference,'stable'); p=nan(size(others)); effect=p; methods=cell(size(others));
                for k=1:numel(others)
                    [p(k),effect(k),methods{k}]=drgo.signedrank_test(means(:,reference),means(:,others(k)));
                end
                adj=drgo.holm(p);
                for k=1:numel(others)
                    symbol='=';
                    if adj(k)<.05 && effect(k)>.5, symbol='+'; elseif adj(k)<.05 && effect(k)<.5, symbol='-'; end
                    signed(end+1,:)={group,V.suite(1),V.dimension(1),V.population(1),V.budget(1), ...
                        alg{others(k)},F,p(k),adj(k),effect(k),symbol,methods{k}}; %#ok<AGROW>
                end
            end
        end
        if complete && K>=3 && F>=2
            win=means==min(means,[],2); tied=sum(win,2)>1;
            for ai=1:K
                wins(end+1,:)={group,V.suite(1),V.dimension(1),V.population(1),V.budget(1),alg{ai},sum(win(:,ai)&~tied),sum(win(:,ai)&tied),F}; %#ok<AGROW>
            end
            rankValues=med;
            if isfield(cfg,'rankStatistic') && strcmp(cfg.rankStatistic,'mean'), rankValues=means; end
            ranks=zeros(F,K); tieTotal=0;
            for fi=1:F
                ranks(fi,:)=drgo.ranks(rankValues(fi,:)); [~,~,gg]=unique(rankValues(fi,:)); tt=accumarray(gg(:),1); tieTotal=tieTotal+sum(tt.^3-tt);
            end
            avg=mean(ranks,1); correction=1-tieTotal/(F*(K^3-K));
            if correction<=eps, statistic=0; pOverall=1;
            else, statistic=max(0,(12*F/(K*(K+1))*sum(avg.^2)-3*F*(K+1))/correction); pOverall=gammainc(statistic/2,(K-1)/2,'upper'); end
            friedman(end+1,:)={group,V.suite(1),V.dimension(1),V.population(1),V.budget(1),F,K,statistic,K-1,pOverall,correction}; %#ok<AGROW>
            for ai=1:K, rankrows(end+1,:)={group,V.suite(1),V.dimension(1),V.population(1),V.budget(1),alg{ai},avg(ai)}; end %#ok<AGROW>
            reference=find(strcmp(alg,targetID),1);
            if ~isempty(reference)
                other=setdiff(1:K,reference,'stable'); se=sqrt(K*(K+1)/(6*F));
                p=erfc(abs(avg(other)-avg(reference))/se/sqrt(2)); adj=drgo.holm(p);
                for k=1:numel(other)
                    posthoc(end+1,:)={group,V.suite(1),V.dimension(1),V.population(1),V.budget(1),alg{other(k)},avg(reference),avg(other(k)),p(k),adj(k),pOverall<.05}; %#ok<AGROW>
                end
            end
        elseif ~complete
            blocked(end+1,:)={group,V.suite(1),V.dimension(1),V.population(1),V.budget(1),'Missing or failed planned runs: no global ranking/posthoc generated'}; %#ok<AGROW>
        end
        if cfg.makePlots && strcmp(group,'main')
            if V.suite(1)==2017, chosen=cfg.subset17; else, chosen=cfg.subset13; end
            for f=reshape(intersect(funs,chosen),1,[])
                drgo.plot_block(V,ids,curves,diagnostics,alg,f,cfg);
            end
        end
        if strcmp(group,'ablation')
            if V.suite(1)==2017, chosen=cfg.subset17; else, chosen=cfg.subset13; end
            for f=reshape(intersect(funs,chosen),1,[])
                newRows=drgo.plot_dynamics(V,ids,diagnostics,alg,f,cfg); dynamics=[dynamics;newRows]; %#ok<AGROW>
            end
        end
    end
end
write(summary,{'group','suite','function','dimension','population','budget','algorithm','planned_n','successful_n','complete', ...
    'mean_error','std_error','median_error','q25_error','q75_error','iqr_error','best_error','mean_seconds','std_seconds'},'summary');
write(pairs,{'group','suite','function','dimension','population','budget','competitor','p_raw','p_holm','probability_DRGO_better','symbol','method'},'mann_whitney');
write(signed,{'group','suite','dimension','population','budget','competitor','paired_functions','p_raw','p_holm','probability_DRGO_better','symbol','method'},'wilcoxon_signed_rank');
write(friedman,{'group','suite','dimension','population','budget','functions','algorithms','statistic','df','p','tie_correction'},'friedman');
write(posthoc,{'group','suite','dimension','population','budget','competitor','DRGO_mean_rank','competitor_mean_rank','p_raw','p_holm','omnibus_significant'},'posthoc');
write(rankrows,{'group','suite','dimension','population','budget','algorithm','mean_rank'},'ranks');
write(wins,{'group','suite','dimension','population','budget','algorithm','unique_best_mean','tied_best_mean','functions'},'wins');
write(blocked,{'group','suite','dimension','population','budget','reason'},'blocked_statistics');
write(dynamics,{'suite','function','dimension','population','budget','algorithm','n','fes', ...
    'diversity_median','exploration_median','exploitation_median','acceptance_median','movement_median','violation_median','mentor_count_median', ...
    'diversity_q25','exploration_q25','exploitation_q25','acceptance_q25','movement_q25','violation_q25','mentor_count_q25', ...
    'diversity_q75','exploration_q75','exploitation_q75','acceptance_q75','movement_q75','violation_q75','mentor_count_q75'},'dynamics');
fprintf('CSV + workbook exported. Parallel task times are not isolated runtime evidence.\n');
    function write(data,names,name)
        if isempty(data), data=cell(0,numel(names)); end
        out=cell2table(data,'VariableNames',names); writetable(out,fullfile(cfg.outDir,[name '.csv']));
        try, writetable(out,fullfile(cfg.outDir,'results.xlsx'),'Sheet',name,'WriteMode','overwritesheet');
        catch ME, warning('DRGO:Excel','CSV saved; Excel export failed: %s',ME.message); end
    end
end
