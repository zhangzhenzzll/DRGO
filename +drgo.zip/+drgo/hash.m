function h = hash(value,isFile)
if nargin<2, isFile=false; end
md=java.security.MessageDigest.getInstance('SHA-256');
if isFile
    f=fopen(value,'rb'); assert(f>=0,'Cannot read file for hash.'); cleanup=onCleanup(@()fclose(f));
    while ~feof(f), bytes=fread(f,1048576,'*uint8'); md.update(typecast(bytes(:),'int8')); end
else
    bytes=unicode2native(char(value),'UTF-8'); md.update(typecast(uint8(bytes(:)),'int8'));
end
digest=typecast(md.digest(),'uint8'); h=lower(reshape(dec2hex(digest,2)',1,[]));
end
