function adjusted = holm(p)
shape=size(p); p=p(:); adjusted=nan(size(p)); valid=find(isfinite(p));
[v,ix]=sort(p(valid)); m=numel(v); last=0;
for i=1:m
    last=max(last,min(1,(m-i+1)*v(i))); adjusted(valid(ix(i)))=last;
end
adjusted=reshape(adjusted,shape);
end
