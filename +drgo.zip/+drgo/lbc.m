function di = lbc(b,n,d,lb,ub,seed)
% Author C++ core, success-history adaptation and population reduction retained.
% Uniform box bounds; all calls pass through the shared FE accounting object.
assert(all(lb==lb(1)) && all(ub==ub(1)),'NL-SHADE-LBC adapter requires uniform box bounds.');
fes=lbc_mex(@(x)b.evaluate(x),double(n),double(d),double(b.Limit),double(seed),double(lb(1)),double(ub(1)));
assert(fes==b.Limit && b.Count==b.Limit);
di=zeros(0,6);
end
