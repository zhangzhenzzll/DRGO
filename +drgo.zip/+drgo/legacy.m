function [diagnostics,seconds] = legacy(b,name,n,d,lb,ub,seed)
% Uploaded implementation, not an independently authenticated canonical code.
% Probe call counts on a constant objective, restore RNG, then hard-stop at FEs.
% No extra REAL objective evaluations are performed by the count probe.
assert(all(lb==lb(1)) && all(ub==ub(1)),'Legacy adapters require scalar bounds.');
fun=str2func(['legacy_' name]); calls=0;
rng(seed,'twister'); [~,~,~]=fun(n,1,lb(1),ub(1),d,@counter,1); c1=calls;
calls=0; rng(seed,'twister'); [~,~,~]=fun(n,2,lb(1),ub(1),d,@counter,1); c2=calls;
perGeneration=c2-c1; initial=c1-perGeneration;
if perGeneration<=0 || initial<0, error('DRGO:LegacySchedule','Cannot infer evaluation schedule for %s.',name); end
horizon=max(1,ceil((b.Limit-initial)/perGeneration));
rng(seed,'twister');
start=tic;
try
    [~,~,~]=fun(n,horizon,lb(1),ub(1),d,@objective,1);
catch ME
    if ~strcmp(ME.identifier,'DRGO:BudgetReached'), rethrow(ME); end
end
seconds=toc(start);
if b.Count~=b.Limit
    error('DRGO:IncompleteLegacy','%s returned at %d of %d evaluations; not padding or accepting.',name,b.Count,b.Limit);
end
diagnostics=zeros(0,6);
    function y=counter(~,~)
        calls=calls+1; y=1;
    end
    function y=objective(x,~)
        y=b.evaluate(x);
    end
end
