function [fun,optimum] = objective(suite,fid,d)
if suite==2013
    fun=@(x)cec13_safe(reshape(x,d,1),fid);
    if fid<=14, optimum=100*fid-1500; else, optimum=100*fid-1400; end
elseif suite==2017
    fun=@(x)cec17_safe(reshape(x,d,1),fid); optimum=100*fid;
elseif suite==0
    if fid==1, fun=@(x)sum((x-0.3).^2);
    else, fun=@(x)sum((x-0.3).^2+10*(1-cos(2*pi*(x-0.3)))); end
    optimum=0;
else
    error('DRGO:Suite','Unknown suite.');
end
end
