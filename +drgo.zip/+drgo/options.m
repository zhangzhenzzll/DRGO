function o = options(patch)
% Frozen final DRGO defaults; only declared ablation/sensitivity options vary.
o=struct('phd_rate',0.1,'senior_start',0.4,'senior_end',0.1, ...
    'schedule_power',1,'fixed_pool',-1,'pc',0.5,'flo',0.2,'fhi',1, ...
    'cr',0.8,'noise',0.1,'contraction',2,'mentor_snapshot',true, ...
    'distinct_difference',true,'spiral',true,'differential',true, ...
    'greedy',true,'elite',true,'boundary','band','repeat_elite',false, ...
    'spiral_signed',true);
if nargin
    keys=fieldnames(patch);
    for i=1:numel(keys)
        if ~isfield(o,keys{i}), error('DRGO:Option','Unknown option: %s',keys{i}); end
        o.(keys{i})=patch.(keys{i});
    end
end
validateattributes(o.pc,{'numeric'},{'scalar','>=',0,'<=',1});
validateattributes(o.cr,{'numeric'},{'scalar','>=',0,'<=',1});
validateattributes(o.phd_rate,{'numeric'},{'scalar','>',0,'<',1});
validateattributes(o.contraction,{'numeric'},{'scalar','nonnegative'});
assert(o.fhi>=o.flo && o.flo>=0 && o.schedule_power>0,'Invalid scale or schedule.');
assert(any(strcmp(o.boundary,{'band','clip','reflect','random'})),'Unknown repair method.');
end
