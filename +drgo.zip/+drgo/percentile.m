function q = percentile(x,p)
% Linear-interpolation percentile without Statistics Toolbox.
x=sort(x(:));
assert(~isempty(x) && all(isfinite(x)) && p>=0 && p<=100,'Invalid percentile input.');
if numel(x)==1, q=x; return; end
position=1+(numel(x)-1)*p/100;
lo=floor(position); hi=ceil(position);
if lo==hi, q=x(lo); else, q=x(lo)+(position-lo)*(x(hi)-x(lo)); end
end
