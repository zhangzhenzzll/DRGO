function jobs = plan(cfg,signature)
a=drgo.algorithms(cfg); jobs=struct('key',{},'suite',{},'fid',{},'d',{},'n',{},'budget',{},'run',{},'seed',{},'algorithm',{},'groups',{},'isolated',{});
lookup=containers.Map('KeyType','char','ValueType','double');
for s=cfg.suites
    if s==2017, fs=cfg.functions17; sub=cfg.subset17; rt=cfg.runtimeFunctions17;
    elseif s==2013, fs=cfg.functions13; sub=cfg.subset13; rt=cfg.runtimeFunctions13;
    else, fs=cfg.functions13; sub=fs; rt=fs; end
    if any(ismember(cfg.groups,{'r11_population','r11_budget','r11_dimension'}))
        selected=a(ismember({a.id},cfg.mainAlgorithmIDs));
        if any(strcmp(cfg.groups,'r11_population'))
            for n=[30 50], add('r11_population',s,sub,30,n,30000,selected,cfg.runs,false); end
        end
        if any(strcmp(cfg.groups,'r11_budget'))
            for b=[30000 100000], add('r11_budget',s,sub,30,30,b,selected,cfg.runs,false); end
        end
        if any(strcmp(cfg.groups,'r11_dimension'))
            for q=1:size(cfg.dimensionBudgetPairs,1)
                add('r11_dimension',s,sub,cfg.dimensionBudgetPairs(q,1),30, ...
                    cfg.dimensionBudgetPairs(q,2),selected,cfg.runs,false);
            end
        end
    end
    if any(strcmp(cfg.groups,'main'))
        for d=cfg.dimensions, add('main',s,fs,d,cfg.population,cfg.budget,a,cfg.runs,false); end
    end
    if any(strcmp(cfg.groups,'supplemental'))
        extra=a(~ismember({a.id},cfg.mainAlgorithmIDs));
        for d=cfg.dimensions
            for ai=1:numel(extra)
                n=cfg.population;
                if isfield(extra(ai).options,'initialMultiplier'), n=extra(ai).options.initialMultiplier*d; end
                add('supplemental',s,fs,d,n,cfg.budget,extra(ai),cfg.runs,false);
            end
        end
    end
    if any(strcmp(cfg.groups,'ablation'))
        variants=a(1); base=a(1);
        patches={struct('fixed_pool',.1),struct('fixed_pool',.25),struct('fixed_pool',.4), ...
            struct('schedule_power',2),struct('spiral',false),struct('differential',false), ...
            struct('pc',0),struct('pc',1),struct('greedy',false)};
        names={'pool10','pool25','pool40','quadratic_pool','no_spiral','no_difference', ...
            'gaussian','cauchy','no_greedy'};
        for k=1:numel(patches)
            v=base; v.id=['DRGO_' names{k}]; v.options=drgo.options(patches{k}); variants(end+1)=v; %#ok<AGROW>
        end
        add('ablation',s,sub,30,cfg.population,cfg.budget,variants,cfg.runs,false);
    end
    if any(strcmp(cfg.groups,'parameters_pc'))
        variants=a(1);
        for pc=cfg.mixProbabilities
            v=a(1); v.id=sprintf('DRGO_pc%g',pc); v.options=drgo.options(struct('pc',pc)); variants(end+1)=v; %#ok<AGROW>
        end
        add('parameters_pc',s,sub,30,cfg.population,cfg.budget,variants,cfg.runs,false);
    end
    if any(strcmp(cfg.groups,'parameters_scale'))
        variants=a(1);
        for k=1:size(cfg.scaleRanges,1)
            v=a(1); v.id=sprintf('DRGO_scale%g_%g',cfg.scaleRanges(k,:));
            v.options=drgo.options(struct('flo',cfg.scaleRanges(k,1),'fhi',cfg.scaleRanges(k,2))); variants(end+1)=v; %#ok<AGROW>
        end
        add('parameters_scale',s,sub,30,cfg.population,cfg.budget,variants,cfg.runs,false);
    end
    if any(strcmp(cfg.groups,'robustness'))
        selected=a(ismember({a.id},cfg.mainAlgorithmIDs));
        for n=cfg.populations, for b=cfg.budgets
            add('robustness',s,sub,30,n,b,selected,cfg.runs,false);
        end, end
    end
    if any(strcmp(cfg.groups,'scaling'))
        selected=a(ismember({a.id},cfg.mainAlgorithmIDs));
        add('scaling',s,fs,cfg.scalingDimension,cfg.population,100000,selected,cfg.runs,false);
    end
    if any(strcmp(cfg.groups,'boundary'))
        variants=a(1);
        for k=1:numel(cfg.boundaries)
            v=a(1); v.id=['DRGO_' cfg.boundaries{k}]; v.options=drgo.options(struct('boundary',cfg.boundaries{k})); variants(end+1)=v; %#ok<AGROW>
        end
        add('boundary',s,sub,30,cfg.population,cfg.budget,variants,cfg.runs,false);
    end
    if any(strcmp(cfg.groups,'runtime'))
        add('runtime',s,sub,30,cfg.population,cfg.budget,a,cfg.runtimeRuns,true);
    end
end
    function add(group,s,fs,d,n,b,variants,repeats,isolated)
        for f=fs, for k=1:numel(variants), for r=1:repeats
            stream=drgo.hash(jsonencode(struct('kind',variants(k).kind,'entry',variants(k).entryName,'options',variants(k).options)));
            seed=mod(cfg.seedBase+1000003*s+10007*f+101*d+53*n+7*b+104729*r+hex2dec(stream(1:8)),2^32-1);
            identity=struct('signature',signature,'suite',s,'fid',f,'d',d,'n',n,'budget',b, ...
                'run',r,'seed',seed,'kind',variants(k).kind,'entryName',variants(k).entryName, ...
                'options',variants(k).options,'isolated',isolated);
            key=drgo.hash(jsonencode(identity));
            if isKey(lookup,key)
                pos=lookup(key); jobs(pos).groups=unique([jobs(pos).groups,{group}],'stable');
            else
                j=struct('key',key,'suite',s,'fid',f,'d',d,'n',n,'budget',b,'run',r,'seed',seed, ...
                    'algorithm',variants(k),'groups',{{group}},'isolated',isolated);
                jobs(end+1)=j; lookup(key)=numel(jobs); %#ok<AGROW>
            end
        end, end, end
    end
end
