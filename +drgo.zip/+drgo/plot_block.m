function plot_block(V,ids,curves,diagnostics,alg,f,cfg)
if ~all(strcmp(V.status(V.function==f),'ok'))
    warning('DRGO:IncompletePlot','Skipping F%d plot: planned runs are incomplete.',f); return;
end
folder=fullfile(cfg.outDir,'figures'); if ~isfolder(folder), mkdir(folder); end
fig=figure('Visible','off','Color','w','Position',[100 100 1200 480]); cleanup=onCleanup(@()close(fig));
tiledlayout(1,2,'Padding','compact'); ax=nexttile; hold(ax,'on'); colors=lines(numel(alg));
boxValues=[]; boxGroup=[]; labels={};
for k=1:numel(alg)
    take=find(V.function==f & strcmp(V.algorithm,alg{k}));
    if isempty(take) || ~all(strcmp(V.status(take),'ok')), continue; end
    matrix=[]; fegrid=[];
    for q=take'
        c=curves{ids(q)}; matrix(end+1,:)=c.y; fegrid=c.fe; %#ok<AGROW>
    end
    if V.suite(1)==2013
        if f<=14, optimum=100*f-1500; else, optimum=100*f-1400; end
    elseif V.suite(1)==2017, optimum=100*f; else, optimum=0; end
    y=max(1e-12,median(matrix-optimum,1));
    semilogy(ax,fegrid,y,'Color',colors(k,:),'DisplayName',alg{k},'LineWidth',1.2);
    labels{end+1}=alg{k}; boxValues=[boxValues;log10(max(1e-12,V.error(take)))]; boxGroup=[boxGroup;numel(labels)*ones(numel(take),1)]; %#ok<AGROW>
end
set(ax,'YScale','log'); xlabel(ax,'Function evaluations'); ylabel(ax,'Median objective error (display floor 1e-12)');
legend(ax,'Location','best','Interpreter','none','FontSize',7); grid(ax,'on');
title(ax,sprintf('CEC%d D%d F%d',V.suite(1),V.dimension(1),f));
ax2=nexttile;
if ~isempty(boxValues)
    boxchart(ax2,boxGroup,boxValues); xticks(ax2,1:numel(labels)); xticklabels(ax2,labels); xtickangle(ax2,55);
    set(ax2,'TickLabelInterpreter','none'); ylabel(ax2,'log10 error (display floor 1e-12)');
end
file=sprintf('CEC%d_D%d_F%02d_N%d_B%d_convergence_boxplot.pdf',V.suite(1),V.dimension(1),f,V.population(1),V.budget(1));
exportgraphics(fig,fullfile(folder,file),'ContentType','vector');
% Raw role diagnostics remain in every checkpoint for ablation plotting.
end
