function rows = plot_dynamics(V,ids,diagnostics,alg,f,cfg)
% Reproducible diversity-based XPL/XPT plus independent operational metrics.
rows={}; folder=fullfile(cfg.outDir,'figures');
if ~all(strcmp(V.status(V.function==f),'ok'))
    warning('DRGO:IncompletePlot','Skipping F%d diagnostics: planned runs are incomplete.',f); return;
end
if ~isfolder(folder), mkdir(folder); end
fig=[];
if cfg.makePlots
    fig=figure('Visible','off','Color','w','Position',[100 100 1250 700]);
    clean=onCleanup(@()close(fig)); tiledlayout(2,3,'Padding','compact');
    axesList=gobjects(1,6); for k=1:6, axesList(k)=nexttile; hold(axesList(k),'on'); end
end
colors=lines(numel(alg));
for ai=1:numel(alg)
    take=find(V.function==f & strcmp(V.algorithm,alg{ai}));
    if isempty(take) || ~all(strcmp(V.status(take),'ok')), continue; end
    first=diagnostics{ids(take(1))}; if isempty(first), continue; end
    fegrid=first(:,1); stack=nan(numel(fegrid),7,numel(take));
    for q=1:numel(take)
        di=diagnostics{ids(take(q))};
        if isempty(di), continue; end
        peak=max(di(:,2));
        if peak<=eps, xpl=zeros(size(di,1),1); else, xpl=100*di(:,2)/peak; end
        xpt=100-xpl;
        values=[di(:,2),xpl,xpt,di(:,3:6)];
        if size(di,1)==1, stack(:,:,q)=repmat(values(1,:),numel(fegrid),1);
        else, stack(:,:,q)=interp1(di(:,1),values,fegrid,'previous',NaN); end
    end
    med=median(stack,3); low=quantile3(stack,.25); high=quantile3(stack,.75);
    for j=1:numel(fegrid)
        rows(end+1,:)=[{V.suite(1),f,V.dimension(1),V.population(1),V.budget(1),alg{ai},numel(take),fegrid(j)},num2cell(med(j,:)),num2cell(low(j,:)),num2cell(high(j,:))]; %#ok<AGROW>
    end
    if ~isempty(fig)
        for metric=1:6
            plot(axesList(metric),fegrid,med(:,metric),'Color',colors(ai,:),'DisplayName',alg{ai});
        end
    end
end
if ~isempty(fig)
    labels={'Normalized population diversity','Exploration XPL (%)','Exploitation XPT (%)', ...
        'Candidate acceptance rate','Normalized accepted movement','Out-of-bounds proposal fraction'};
    for k=1:6
        xlabel(axesList(k),'Function evaluations'); ylabel(axesList(k),labels{k});
        legend(axesList(k),'Interpreter','none','FontSize',6,'Location','best'); grid(axesList(k),'on');
    end
    exportgraphics(fig,fullfile(folder,sprintf('CEC%d_D%d_F%02d_dynamics.pdf',V.suite(1),V.dimension(1),f)),'ContentType','vector');
end
end
function out=quantile3(x,p)
x=sort(x,3); n=size(x,3); at=1+(n-1)*p; lo=floor(at); hi=ceil(at);
out=x(:,:,lo)+(at-lo)*(x(:,:,hi)-x(:,:,lo));
end
