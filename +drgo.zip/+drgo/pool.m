function p = pool(cfg)
p=[];
if ~cfg.useParallel || ~license('test','Distrib_Computing_Toolbox')
    fprintf('Parallel toolbox unavailable or disabled: serial execution.\n'); return;
end
existing=gcp('nocreate');
if ~isempty(existing)
    if isa(existing,'parallel.ThreadPool')
        fprintf('Existing thread pool is not used: CEC global caches require processes. Running serially.\n'); return;
    end
    if ~isa(existing.Cluster,'parallel.cluster.Local')
        fprintf('Existing remote pool is not used because CEC paths are local. Running serially.\n'); return;
    end
    if existing.NumWorkers<=cfg.maxWorkers, p=existing; return; end
    fprintf('Existing pool exceeds configured cap; running serially without deleting it.\n'); return;
end
try
    cluster=parcluster('local'); cap=min(cluster.NumWorkers,cfg.maxWorkers);
    if ispc
        [~,sys]=memory;
        cap=min(cap,max(1,floor(double(sys.PhysicalMemory.Available)/(cfg.memoryGBPerWorker*1024^3))));
    end
    cap=max(1,floor(cap));
    p=parpool('Processes',cap);
    fprintf('Process pool: %d workers.\n',p.NumWorkers);
catch ME
    warning('DRGO:PoolFallback','Process pool unavailable (%s). Using serial execution.',ME.message);
end
end
