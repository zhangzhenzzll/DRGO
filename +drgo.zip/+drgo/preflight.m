function signature = preflight(root,cfg)
% Validate ALL required files BEFORE entering MEX: original missing-file code can crash.
entries=struct('path',{},'sha256',{}); requirements={};
dims=cfg.dimensions;
if any(ismember(cfg.groups,{'ablation','parameters_pc','parameters_scale', ...
        'robustness','boundary','runtime'})), dims=unique([dims 30]); end
if any(strcmp(cfg.groups,'scaling')), dims=unique([dims cfg.scalingDimension]); end
if any(strcmp(cfg.groups,'r11_dimension'))
    dims=unique([dims reshape(cfg.dimensionBudgetPairs(:,1),1,[])]);
end
for suite=cfg.suites
    if suite==0, continue; end
    if suite==2013
        requirements(end+1,:)={fullfile(root,'input_data','shift_data.txt'),10*max(dims)}; %#ok<AGROW>
        for d=dims, requirements(end+1,:)={fullfile(root,'input_data',sprintf('M_D%d.txt',d)),10*d*d}; end %#ok<AGROW>
    else
        fs=cfg.functions17;
        if any(ismember(cfg.groups,{'parameters_pc','parameters_scale', ...
                'robustness','boundary'})), fs=union(fs,cfg.subset17); end
        if any(strcmp(cfg.groups,'runtime')), fs=union(fs,cfg.runtimeFunctions17); end
        for f=fs
            blocks=1+9*(f>=21);
            requirements(end+1,:)={fullfile(root,'input_data17',sprintf('shift_data_%d.txt',f)),100*blocks}; %#ok<AGROW>
            for d=dims
                requirements(end+1,:)={fullfile(root,'input_data17',sprintf('M_%d_D%d.txt',f,d)),blocks*d*d}; %#ok<AGROW>
                if (f>=11 && f<=20) || f>=29
                    sh=1+9*(f>=29);
                    requirements(end+1,:)={fullfile(root,'input_data17',sprintf('shuffle_data_%d_D%d.txt',f,d)),sh*d}; %#ok<AGROW>
                end
            end
        end
    end
end
missing={};
for i=1:size(requirements,1)
    path=requirements{i,1};
    if ~isfile(path), missing{end+1}=path; continue; end %#ok<AGROW>
    f=fopen(path,'r'); cleanup=onCleanup(@()fclose(f)); v=fscanf(f,'%f'); clear cleanup;
    if numel(v)<requirements{i,2} || any(~isfinite(v))
        error('DRGO:DataInvalid','Short or nonfinite data: %s',path);
    end
    if contains(path,'shuffle_data')
        token=regexp(path,'_D(\d+)\.txt$','tokens','once'); d=str2double(token{1});
        for j=1:requirements{i,2}/d
            block=v((j-1)*d+1:j*d);
            assert(isequal(sort(block(:))',(1:d)),'Invalid shuffle permutation: %s',path);
        end
    end
    entries(end+1)=struct('path',erase(path,[root filesep]),'sha256',drgo.hash(path,true)); %#ok<AGROW>
end
if ~isempty(missing)
    shown=missing(1:min(12,numel(missing)));
    error('DRGO:MissingCECData','Missing %d CEC files. Put ORIGINAL data in input_data / input_data17.\n%s\nNo CEC run was started.',numel(missing),strjoin(shown,newline));
end
% Rebuild from reviewed source, not from unverified uploaded binary.
for suite=cfg.suites
    if suite==0, continue; end
    year=suite-2000; name=sprintf('cec%d_safe',year);
    src=fullfile(root,'matlab','cec',[name '.cpp']);
    bin=fullfile(root,'matlab','cec',[name '.' mexext]);
    stamp=[bin '.sha256']; sourceHash=drgo.hash(src,true);
    needs=~isfile(bin) || ~isfile(stamp);
    if ~needs, needs=~strcmp(strtrim(fileread(stamp)),sourceHash); end
    if needs
        fprintf('Compiling %s from reviewed source...\n',name);
        clear(name);
        try, mex('-R2018a','-outdir',fullfile(root,'matlab','cec'),src);
        catch ME
            error('DRGO:MEXCompiler', ...
                ['Cannot build %s. On Windows, open MATLAB Home > Add-Ons, install ' ...
                 '"MATLAB Support for MinGW-w64 C/C++ Compiler", restart MATLAB, ' ...
                 'then run mex -setup C++.\nOriginal compiler message:\n%s'],name,ME.message);
        end
        f=fopen(stamp,'w'); fprintf(f,'%s',sourceHash); fclose(f);
    end
    entries(end+1)=struct('path',erase(bin,[root filesep]),'sha256',drgo.hash(bin,true)); %#ok<AGROW>
end
% Build/test the recent author core before scheduling expensive work.
if isfield(cfg,'includeRecent') && cfg.includeRecent
    folder=fullfile(root,'matlab','native'); addpath(folder);
    src=fullfile(folder,'lsrtde_mex.cpp'); core=fullfile(folder,'lsrtde_core.hpp');
    bin=fullfile(folder,['lsrtde_mex.' mexext]); stamp=[bin '.sha256'];
    h=drgo.hash([drgo.hash(src,true) drgo.hash(core,true)]);
    if ~isfile(bin) || ~isfile(stamp) || ~strcmp(strtrim(fileread(stamp)),h)
        clear lsrtde_mex;
        try, mex('-R2018a','-outdir',folder,src);
        catch ME, error('DRGO:MEXCompiler', ...
            ['L-SRTDE compilation failed. On Windows, install "MATLAB Support for ' ...
             'MinGW-w64 C/C++ Compiler" from Home > Add-Ons, restart MATLAB, then ' ...
             'run mex -setup C++.\nOriginal compiler message:\n%s'],ME.message); end
        f=fopen(stamp,'w'); fprintf(f,'%s',h); fclose(f);
    end
    for n=[30 50 600]
        b=drgo.Budget(@(x)sum((x-.3).^2),n,3000,-100*ones(1,10),100*ones(1,10));
        drgo.lsrtde(b,n,10,-100*ones(1,10),100*ones(1,10),123);
        first=b.result();
        b=drgo.Budget(@(x)sum((x-.3).^2),n,3000,-100*ones(1,10),100*ones(1,10));
        drgo.lsrtde(b,n,10,-100*ones(1,10),100*ones(1,10),123);
        second=b.result();
        assert(isequal(first.curve,second.curve) && first.fes==3000,'L-SRTDE preflight failed.');
    end
    entries(end+1)=struct('path',erase(bin,[root filesep]),'sha256',drgo.hash(bin,true));
    entries(end+1)=struct('path',erase(core,[root filesep]),'sha256',drgo.hash(core,true));
    fprintf('L-SRTDE budget and reproducibility preflight passed.\n');
end
% Build/test the recent author core before scheduling expensive work.
if isfield(cfg,'includeRecent') && cfg.includeRecent
    folder=fullfile(root,'matlab','native'); addpath(folder);
    src=fullfile(folder,'lbc_mex.cpp'); core=fullfile(folder,'lbc_core.hpp');
    bin=fullfile(folder,['lbc_mex.' mexext]); stamp=[bin '.sha256'];
    h=drgo.hash([drgo.hash(src,true) drgo.hash(core,true)]);
    if ~isfile(bin) || ~isfile(stamp) || ~strcmp(strtrim(fileread(stamp)),h)
        clear lbc_mex;
        try, mex('-R2018a','-outdir',folder,src);
        catch ME, error('DRGO:MEXCompiler', ...
            ['NL-SHADE-LBC compilation failed. On Windows, install "MATLAB Support ' ...
             'for MinGW-w64 C/C++ Compiler" from Home > Add-Ons, restart MATLAB, ' ...
             'then run mex -setup C++.\nOriginal compiler message:\n%s'],ME.message); end
        f=fopen(stamp,'w'); fprintf(f,'%s',h); fclose(f);
    end
    for n=[30 50 690]
        b=drgo.Budget(@(x)sum((x-.3).^2),n,3000,-100*ones(1,10),100*ones(1,10));
        drgo.lbc(b,n,10,-100*ones(1,10),100*ones(1,10),123);
        first=b.result();
        b=drgo.Budget(@(x)sum((x-.3).^2),n,3000,-100*ones(1,10),100*ones(1,10));
        drgo.lbc(b,n,10,-100*ones(1,10),100*ones(1,10),123);
        second=b.result();
        assert(isequal(first.curve,second.curve) && first.fes==3000,'NL-SHADE-LBC preflight failed.');
    end
    entries(end+1)=struct('path',erase(bin,[root filesep]),'sha256',drgo.hash(bin,true));
    entries(end+1)=struct('path',erase(core,[root filesep]),'sha256',drgo.hash(core,true));
    fprintf('NL-SHADE-LBC budget and reproducibility preflight passed.\n');
end
% Initialize every planned function before optimization, including the F20 loader.
for suite=cfg.suites
    if suite==0, continue; end
    if suite==2013, fs=cfg.functions13; else, fs=cfg.functions17; end
    for d=dims
        for fid=fs
            [fun,~]=drgo.objective(suite,fid,d); value=fun(zeros(1,d));
            assert(isfinite(value),'CEC initialization failed: %d F%d D%d.',suite,fid,d);
        end
    end
end
% Catch obvious data/source mismatch at the known F1 optimum, for every dimension.
for suite=cfg.suites
    if suite==0, continue; end
    if suite==2013, file=fullfile(root,'input_data','shift_data.txt');
    else, file=fullfile(root,'input_data17','shift_data_1.txt'); end
    f=fopen(file,'r'); shift=fscanf(f,'%f'); fclose(f);
    for d=dims
        [fun,opt]=drgo.objective(suite,1,d); value=fun(shift(1:d)');
        assert(abs(value-opt)<1e-6,'CEC F1 optimum check failed: %d D%d.',suite,d);
    end
end
code=[dir(fullfile(root,'matlab','**','*.m'));dir(fullfile(root,'matlab','**','*.cpp'));dir(fullfile(root,'*.m'))];
for i=1:numel(code)
    path=fullfile(code(i).folder,code(i).name);
    entries(end+1)=struct('path',erase(path,[root filesep]),'sha256',drgo.hash(path,true)); %#ok<AGROW>
end
[~,idx]=sort({entries.path}); entries=entries(idx);
signature=drgo.hash(jsonencode(entries));
if ~isfolder(cfg.outDir), mkdir(cfg.outDir); end
save(fullfile(cfg.outDir,'source_data_manifest.mat'),'entries','signature');
f=fopen(fullfile(cfg.outDir,'source_data_manifest.json'),'w'); fprintf(f,'%s',jsonencode(entries,'PrettyPrint',true)); fclose(f);
end
