function r = ranks(x)
% Average ranks for ties, independent of Statistics and Machine Learning Toolbox.
shape=size(x); x=x(:); [v,order]=sort(x); r=zeros(size(x)); i=1;
while i<=numel(x)
    j=i; while j<numel(x) && v(j+1)==v(i), j=j+1; end
    r(order(i:j))=(i+j)/2; i=j+1;
end
r=reshape(r,shape);
end
