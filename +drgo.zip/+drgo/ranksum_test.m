function [p,probabilityBetter,method] = ranksum_test(x,y)
% Two-sided Mann-Whitney rank sum, average ranks, tie correction and continuity.
% A = P(X<Y) + .5 P(X=Y); larger A favors the first (minimizing) algorithm.
x=x(:); y=y(:); n=numel(x); m=numel(y); joined=[x;y];
assert(n>0 && m>0 && all(isfinite(joined)),'Invalid rank-sum samples.');
r=drgo.ranks(joined); u=sum(r(1:n))-n*(n+1)/2;
probabilityBetter=1-u/(n*m);
if all(joined==joined(1)), p=1; method='All observations tied'; return; end
if exist('ranksum','file')==2 && license('test','Statistics_Toolbox')
    p=ranksum(x,y,'method','approximate'); method='MATLAB ranksum approximate'; return;
end
[~,~,g]=unique(joined); counts=accumarray(g,1); total=n+m;
variance=n*m/12*(total+1-sum(counts.^3-counts)/(total*(total-1)));
if variance<=0, p=1; else, z=max(0,abs(u-n*m/2)-0.5)/sqrt(variance); p=erfc(z/sqrt(2)); end
method='Normal approximation; tie and continuity correction';
end
