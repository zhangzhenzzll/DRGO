function y = repair(y,lb,ub,mode)
assert(all(isfinite(y(:))) && isreal(y),'Nonfinite proposal.');
lo=repmat(lb,size(y,1),1); hi=repmat(ub,size(y,1),1); width=hi-lo;
switch mode
    case 'clip'
        y=min(max(y,lo),hi);
    case 'reflect'
        z=mod(y-lo,2*width); y=lo+min(z,2*width-z);
    case 'random'
        bad=y<lo | y>hi; y(bad)=lo(bad)+rand(nnz(bad),1).*width(bad);
    case 'band'
        bad=y<lo; y(bad)=lo(bad)+0.05*rand(nnz(bad),1).*width(bad);
        bad=y>hi; y(bad)=hi(bad)-0.05*rand(nnz(bad),1).*width(bad);
    otherwise
        error('DRGO:Repair','Unknown boundary policy.');
end
y=min(max(y,lo),hi);
end
