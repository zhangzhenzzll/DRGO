function diagnostics = run(b,n,d,lb,ub,o)
% Three-stage role framework retained; frozen evaluated mentor snapshot.
validateattributes(n,{'numeric'},{'scalar','integer','>=',4});
x=lb+rand(n,d).*(ub-lb); fit=zeros(n,1);
for i=1:n, fit(i)=b.evaluate(x(i,:)); end
npd=min(n-1,max(2,round(n*o.phd_rate)));
diagnostics=zeros(0,6); lastLog=-Inf; interval=max(1,(b.Limit-n)/100);
while b.Count<b.Limit
    [fit,idx]=sort(fit); x=x(idx,:);
    first=1+double(o.elite); evalFirst=first;
    if o.repeat_elite, evalFirst=1; end
    progress=min(1,(b.Count-n+min(n-evalFirst+1,b.Limit-b.Count))/max(1,b.Limit-n));
    a=1-progress; w=a^2;
    rate=o.senior_start+(o.senior_end-o.senior_start)*progress^o.schedule_power;
    if o.fixed_pool>=0, rate=o.fixed_pool; end
    m=max(npd,min(n,round(n*rate))); y=x;
    ip=first:npd; im=npd+1:n;
    l=(2*rand(numel(ip),1)-1)*a;
    distance=abs(b.BestPosition-x(ip,:));
    if o.spiral_signed, distance=x(ip,:)-b.BestPosition; end
    spiral=distance.*exp(l).*cos(2*pi*l);
    y(ip,:)=b.BestPosition+a^o.contraction*spiral*double(o.spiral)+o.noise*w*randn(numel(ip),d);
    k=min(randi(m,numel(im),1),randi(m,numel(im),1));
    if o.mentor_snapshot, mentor=x(k,:); else, mentor=y(k,:); end
    y(im,:)=x(im,:)+rand(numel(im),d).*(mentor-x(im,:));
    r1=randi(n,numel(im),1); r2=randi(n,numel(im),1);
    if o.distinct_difference
        for q=1:numel(im)
            allowed=[1:im(q)-1,im(q)+1:n]; ix=randperm(n-1,2);
            r1(q)=allowed(ix(1)); r2(q)=allowed(ix(2));
        end
    end
    prob=rand(numel(im),1);
    u=max(eps,min(1-eps,rand(numel(im),d)));
    cauchy=tan(pi*(u-0.5)); gaussian=randn(numel(im),d);
    choose=repmat(prob<o.pc,1,d); step=gaussian; step(choose)=cauchy(choose);
    scale=o.flo+(o.fhi-o.flo)*rand(numel(im),1);
    mutation=step.*(x(r1,:)-x(r2,:)).*scale;
    mask=rand(numel(im),d)<o.cr;
    y(im,:)=y(im,:)+mutation.*mask*double(o.differential);
    violation=mean(reshape(y<lb | y>ub,[],1));
    y=drgo.repair(y,lb,ub,o.boundary); old=x; accepted=0; done=0;
    for i=evalFirst:n
        if b.Count>=b.Limit, break; end
        val=b.evaluate(y(i,:)); done=done+1;
        if ~o.greedy || val<fit(i)
            x(i,:)=y(i,:); fit(i)=val; accepted=accepted+1;
        end
    end
    if b.Count-lastLog>=interval || b.Count==b.Limit
        diversity=mean(abs(x-median(x,1))./(ub-lb),'all');
        movement=mean(sqrt(sum(((x-old)./(ub-lb)).^2,2))/sqrt(d));
        diagnostics(end+1,:)=[b.Count,diversity,accepted/max(done,1),movement,violation,m]; %#ok<AGROW>
        lastLog=b.Count;
    end
end
end
