function [p,probabilityBetter,method] = signedrank_test(x,y)
% Two-sided paired Wilcoxon signed-rank test across benchmark functions.
% Zero differences are removed. probabilityBetter is the paired common-
% language effect: P(x<y)+0.5P(x=y), so larger values favor x for minimization.
x=x(:); y=y(:);
assert(numel(x)==numel(y) && all(isfinite(x)) && all(isfinite(y)), ...
    'Signed-rank samples must be paired, finite, and equally sized.');
probabilityBetter=mean(x<y)+0.5*mean(x==y);
d=x-y; d(d==0)=[]; n=numel(d);
if n==0, p=1; method='All paired differences zero'; return; end
if exist('signrank','file')==2 && license('test','Statistics_Toolbox')
    p=signrank(x,y,'method','approximate');
    method='MATLAB signrank approximate';
    return;
end
r=drgo.ranks(abs(d)); wplus=sum(r(d>0));
mu=n*(n+1)/4;
[~,~,groups]=unique(abs(d)); counts=accumarray(groups,1);
% Averaging a tied block of size t reduces sum(r_i^2) by (t^3-t)/12;
% Var(W+) is one quarter of the resulting squared-rank sum.
variance=(n*(n+1)*(2*n+1)-0.5*sum(counts.^3-counts))/24;
if variance<=0
    p=1;
else
    z=max(0,abs(wplus-mu)-0.5)/sqrt(variance);
    p=erfc(z/sqrt(2));
end
method='Normal approximation; tie and continuity correction';
end
