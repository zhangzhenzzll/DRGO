function status = task(job,cfg,root)
% Worker writes ONLY its own atomic checkpoint. No concurrent Excel writes.
old=pwd; cleanup=onCleanup(@()cd(old)); cd(root);
file=fullfile(cfg.outDir,'raw',[job.key '.mat']);
status=struct('key',job.key,'ok',false,'cached',false,'message','');
if cfg.resume && isfile(file)
    s=load(file,'record');
    if strcmp(s.record.status,'ok') && s.record.fes==job.budget && strcmp(s.record.job.key,job.key)
        status.ok=true; status.cached=true; return;
    end
end
record=struct('job',job,'status','failed','message','','fes',0,'best',NaN,'bestPosition',[], ...
    'budget',job.budget,'feGrid',[],'curve',[],'diagnostics',[],'seconds',NaN, ...
    'objectiveSeconds',NaN,'objectiveProfiling',false,'optimum',NaN,'error',NaN, ...
    'matlabVersion',version,'computer',computer,'parallelTiming',~job.isolated);
b=[];
try
    [fun,optimum]=drgo.objective(job.suite,job.fid,job.d);
    if job.suite==0, [lb,ub]=drgo.bounds(-5,5,job.d);
    else, [lb,ub]=drgo.bounds(-100,100,job.d); end
    % Warm MEX/cache before timing, excluded from budget and disclosed separately.
    warm=fun((lb+ub)/2); assert(isfinite(warm),'Objective preflight failed.');
    rng(job.seed,'twister');
    b=drgo.Budget(fun,job.n,job.budget,lb,ub,cfg.profileObjective);
    start=tic;
    switch job.algorithm.kind
        case 'drgo', di=drgo.run(b,job.n,job.d,lb,ub,job.algorithm.options);
        case 'de', di=drgo.de(b,job.n,job.d,lb,ub);
        case 'clpso', di=drgo.clpso(b,job.n,job.d,lb,ub);
        case 'lbc', di=drgo.lbc(b,job.n,job.d,lb,ub,job.seed);
        case 'lsrtde', di=drgo.lsrtde(b,job.n,job.d,lb,ub,job.seed);
        case 'baseline', [di,elapsed]=drgo.baseline(b,job.algorithm.entryName,job.n,job.d,lb,ub,job.seed);
        otherwise, error('DRGO:Algorithm','Unknown algorithm.');
    end
    if ~strcmp(job.algorithm.kind,'baseline'), elapsed=toc(start); end
    result=b.result();
    assert(result.fes==job.budget && all(isfinite(result.curve)) && all(diff(result.curve)<=0),'Budget/curve invariant failed.');
    verified=fun(result.bestPosition); % One independent post-run audit, not an optimization query.
    assert(abs(verified-result.best)<=1e-9*max(1,abs(verified)),'Best position/score mismatch.');
    keys=fieldnames(result); for k=1:numel(keys), record.(keys{k})=result.(keys{k}); end
    record.seconds=elapsed; record.diagnostics=di; record.optimum=optimum;
    record.error=result.best-optimum;
    if record.error < -1e-8*max(1,abs(optimum)), error('DRGO:BelowOptimum','Check benchmark source/data: value below known optimum.'); end
    record.status='ok'; record.auditEvaluations=2; status.ok=true;
catch ME
    record.message=getReport(ME,'extended','hyperlinks','off');
    if ~isempty(b), record.fes=b.Count; end
    status.message=ME.message;
end
temp=[file '.tmp.mat']; save(temp,'record','-v7'); movefile(temp,file,'f');
end
